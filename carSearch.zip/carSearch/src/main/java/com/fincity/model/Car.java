package com.fincity.model;

public class Car {
	
	public Car() {
		super();
	}

	public Car(int carId, String carName, String carModel, String carManufacturer, int manufaturingYear, String carColor) {
		super();
		this.carId = carId;
		this.carName = carName;
		this.carModel = carModel;
		this.carManufacturer = carManufacturer;
		this.manufaturingYear = manufaturingYear;
		this.carColor = carColor;
	}

	private int carId;
	
	private String carName;
	
	private String carModel;
	
	private String carManufacturer;
	
	private int manufaturingYear;
	
	private String carColor;

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public String getCarManufacturer() {
		return carManufacturer;
	}

	public void setCarManufacturer(String carManufacturer) {
		this.carManufacturer = carManufacturer;
	}

	public int getManufaturingYear() {
		return manufaturingYear;
	}

	public void setManufaturingYear(int manufaturingYear) {
		this.manufaturingYear = manufaturingYear;
	}

	public String getCarColor() {
		return carColor;
	}

	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}
	
	

}
