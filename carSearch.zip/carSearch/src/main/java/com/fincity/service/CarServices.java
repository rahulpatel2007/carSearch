package com.fincity.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fincity.model.Car;

@Service
public interface CarServices {

	
	public List<Car> getAllCars();
	
	public Car getCarByName(Car car);
	
	public Car getCarByModel(Car car);
	
	public Car getCarByManufaturer(Car car);
	
	public Car getCarByManucfacturingYear(Car car);
	
	public Car getCarByColor(Car car);
	
	public int saveCar(Car car);
	
	public int updateCar(Car car);
	
	public int deleteCar(Car car);
	
	
}
