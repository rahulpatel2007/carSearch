package com.fincity.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fincity.dao.CarDao;
import com.fincity.model.Car;

@Service
public class CarServiceImpl implements CarServices {
	
	@Autowired
	private CarDao dao;

	@Override
	public List<Car> getAllCars() {
	
		ResultSet rs = dao.getAllCars();
		
		List<Car> cars = new ArrayList<Car>();
		
		try {
			while(rs.next()) {
				
				Car c = new Car();
				
				c.setCarId(rs.getInt(1));
				
				c.setCarName(rs.getString(2));
				
				c.setCarModel(rs.getString(3));
				
				c.setCarManufacturer(rs.getString(4));
				
				c.setManufaturingYear(rs.getInt(5));
				
				c.setCarColor(rs.getString(6));
				
				cars.add(c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cars;
		
	}

	@Override
	public Car getCarByName(Car car) {


		ResultSet rs = dao.getCarByName(car);
		
	//	System.out.println("car fatched");
		
		List<Car> cars = new ArrayList<Car>();
		
		try {
			while(rs.next()) {

				
				  Car c = new Car();
				  
				  c.setCarId(rs.getInt(1));
				  
				  c.setCarName(rs.getString(2));
				  
				  c.setCarModel(rs.getString(3));
				  
				  c.setCarManufacturer(rs.getString(4));
				  
				  c.setManufaturingYear(rs.getInt(5));
				  
				  c.setCarColor(rs.getString(6));
				  
				  cars.add(c);
				 
				
				
	//			System.out.println(rs.getInt(1) + rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cars.get(0);
		
	}

	@Override
	public Car getCarByModel(Car car) {


		ResultSet rs = dao.getCarByModel(car);
		
	//	System.out.println("car fatched");
		
		List<Car> cars = new ArrayList<Car>();
		
		try {
			while(rs.next()) {

				
				  Car c = new Car();
				  
				  c.setCarId(rs.getInt(1));
				  
				  c.setCarName(rs.getString(2));
				  
				  c.setCarModel(rs.getString(3));
				  
				  c.setCarManufacturer(rs.getString(4));
				  
				  c.setManufaturingYear(rs.getInt(5));
				  
				  c.setCarColor(rs.getString(6));
				  
				  cars.add(c);
				 
				
				
	//			System.out.println(rs.getInt(1) + rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cars.get(0);
	}

	@Override
	public Car getCarByManufaturer(Car car) {


		ResultSet rs = dao.getCarByManufaturerName(car);
		
	//	System.out.println("car fatched");
		
		List<Car> cars = new ArrayList<Car>();
		
		try {
			while(rs.next()) {

				
				  Car c = new Car();
				  
				  c.setCarId(rs.getInt(1));
				  
				  c.setCarName(rs.getString(2));
				  
				  c.setCarModel(rs.getString(3));
				  
				  c.setCarManufacturer(rs.getString(4));
				  
				  c.setManufaturingYear(rs.getInt(5));
				  
				  c.setCarColor(rs.getString(6));
				  
				  cars.add(c);
				 
				
				
	//			System.out.println(rs.getInt(1) + rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cars.get(0);
	}

	@Override
	public Car getCarByManucfacturingYear(Car car) {



		ResultSet rs = dao.getCarByManufaturingYear(car);	
	//	System.out.println("car fatched");
		
		List<Car> cars = new ArrayList<Car>();
		
		try {
			while(rs.next()) {

				
				  Car c = new Car();
				  
				  c.setCarId(rs.getInt(1));
				  
				  c.setCarName(rs.getString(2));
				  
				  c.setCarModel(rs.getString(3));
				  
				  c.setCarManufacturer(rs.getString(4));
				  
				  c.setManufaturingYear(rs.getInt(5));
				  
				  c.setCarColor(rs.getString(6));
				  
				  cars.add(c);
				 
				
				
	//			System.out.println(rs.getInt(1) + rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cars.get(0);
	}

	@Override
	public Car getCarByColor(Car car) {


		ResultSet rs = dao.getCarByColor(car);	
	//	System.out.println("car fatched");
		
		List<Car> cars = new ArrayList<Car>();
		
		try {
			while(rs.next()) {

				
				  Car c = new Car();
				  
				  c.setCarId(rs.getInt(1));
				  
				  c.setCarName(rs.getString(2));
				  
				  c.setCarModel(rs.getString(3));
				  
				  c.setCarManufacturer(rs.getString(4));
				  
				  c.setManufaturingYear(rs.getInt(5));
				  
				  c.setCarColor(rs.getString(6));
				  
				  cars.add(c);
				 
				
				
	//			System.out.println(rs.getInt(1) + rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cars.get(0);
	}

	@Override
	public int saveCar(Car car) {

		return dao.saveCar(car);
		
	}

	@Override
	public int updateCar(Car car) {
		return dao.updateCar(car);
	}

	@Override
	public int deleteCar(Car car) {


		return dao.deleteCar(car);
	}

	

}
