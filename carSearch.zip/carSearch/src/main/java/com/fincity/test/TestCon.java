package com.fincity.test;

import com.fincity.db.*;

public class TestCon {

	public static void main(String[] args) {

		DbUtility db = new DbUtility();
		
		System.out.println(db.getConnection());
		
	}

}
