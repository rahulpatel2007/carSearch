package com.fincity.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fincity.model.Car;
import com.fincity.service.CarServices;

@RestController
@RequestMapping(path="/car")
public class CarController {

	@Autowired
	private CarServices carService;
	
	
	//to check our service is up and running.
	@GetMapping
	public String check() {
		
		return "welcome to car search.";
	}
	
	@RequestMapping(method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public Car saveCar(@RequestBody Car car) {

		if (carService.saveCar(car) != 0) {

			return car;
		} else {

			return null;
		}

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/cars", consumes = "application/json", produces = "application/json")
	public List<Car> getAllCars() {

		return carService.getAllCars();
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/{id}",consumes = "application/json", produces = "application/json")
	public Car updateCar(@RequestBody Car car) {

		if (carService.saveCar(car) != 0) {

			return car;
		} else {

			return null;
		}

	}
	
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/{id}",consumes = "application/json", produces = "application/json")
	public Car deleteCar(@RequestBody Car car) {

		if (carService.deleteCar(car) != 0) {

			return car;
		} else {

			return null;
		}

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/name/{name}", consumes = "application/json", produces = "application/json")
	public Car getCarByName(@PathVariable("name") String name) {

		Car c = new Car();
		c.setCarName(name);
		return carService.getCarByName(c);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/model/{model}", consumes = "application/json", produces = "application/json")
	public Car getCarByModel(@PathVariable("model") String model) {

		Car c = new Car();
		c.setCarModel(model);
		return carService.getCarByModel(c);
	}
	

	@RequestMapping(method = RequestMethod.GET, value = "/manufacturingYear/{year}", consumes = "application/json", produces = "application/json")
	public Car getCarByManufacturingYear(@PathVariable("year") int year) {

		Car c = new Car();
		c.setManufaturingYear(year);
		return carService.getCarByManucfacturingYear(c);
				
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/manufacturerName/{name}", consumes = "application/json", produces = "application/json")
	public Car getCarByManufacturerName(@PathVariable("name") String name) {

		Car c = new Car();
		c.setCarManufacturer(name);
		return carService.getCarByManufaturer(c);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/color/{color}", consumes = "application/json", produces = "application/json")
	public Car getCarByColor(@PathVariable("color") String color) {

		Car c = new Car();
		c.setCarColor(color);
		return carService.getCarByColor(c);
	}
}
