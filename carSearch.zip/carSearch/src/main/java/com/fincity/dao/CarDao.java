package com.fincity.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fincity.db.DbUtility;
import com.fincity.model.Car;



@Repository
public class CarDao {
	
	@Autowired
	private DbUtility utility;
	
	PreparedStatement pst;
	
	ResultSet rs;

	
	public ResultSet getAllCars(){
		
		String sql = "select * from car";
		
		pst = utility.createPst(sql);
		
		rs = utility.query(pst);
								
		return rs;
		
	}
	
	public ResultSet getCarByName(Car car){
		
	//	System.out.println(car.getCarName());
		
		String sql = "select * from car where carName= ?";
		
		pst = utility.createPst(sql);
		
		try {
			pst.setString(1, car.getCarName());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		rs = utility.query(pst);
								
		return rs;
		
	}
	
	public ResultSet getCarByModel(Car car){
		
	//	System.out.println(car.getCarName());
		
		String sql = "select * from car where carModel= ?";
		
		pst = utility.createPst(sql);
		
		try {
			pst.setString(1, car.getCarModel());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		rs = utility.query(pst);
								
		return rs;
		
	}
	
	
	public ResultSet getCarByManufaturerName(Car car){
		
	//	System.out.println(car.getCarName());
		
		String sql = "select * from car where carManufacturer= ?";
		
		pst = utility.createPst(sql);
		
		try {
			pst.setString(1, car.getCarManufacturer());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		rs = utility.query(pst);
								
		return rs;
		
	}
	
	public ResultSet getCarByManufaturingYear(Car car){
		
	//	System.out.println(car.getCarName());
		
		String sql = "select * from car where manufacturingYear= ?";
		
		pst = utility.createPst(sql);
		
		try {
			pst.setInt(1, car.getManufaturingYear());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		rs = utility.query(pst);
								
		return rs;
		
	}
	
	public ResultSet getCarByColor(Car car){
		
	//	System.out.println(car.getCarName());
		
		String sql = "select * from car where carColor= ?";
		
		pst = utility.createPst(sql);
		
		try {
			pst.setString(1, car.getCarColor());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		rs = utility.query(pst);
								
		return rs;
		
	}
	
	public int saveCar(Car car) {
		String sql = "insert into car value(?,?,?,?,?,?)";
		
		pst = utility.createPst(sql);
		
		try {
			pst.setInt(1, car.getCarId());
			pst.setString(2, car.getCarName());
			pst.setString(3, car.getCarModel());
			pst.setString(4, car.getCarManufacturer());
			pst.setInt(5, car.getManufaturingYear());
			pst.setString(6, car.getCarColor());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int count  = utility.update(pst);
		
		return count;
		
		
		
		
	}
	
	public int updateCar(Car car) {
		String sql = "update car set carId = ?, carName= ?, carModel= ?, carManufacturer = ?, carManufacturingYear = ?, carColor = ? where carId = ?)";
		
		pst = utility.createPst(sql);
		
		try {
			pst.setInt(1, car.getCarId());
			pst.setString(2, car.getCarName());
			pst.setString(3, car.getCarModel());
			pst.setString(4, car.getCarManufacturer());
			pst.setInt(5, car.getManufaturingYear());
			pst.setString(6, car.getCarColor());
			pst.setInt(7, car.getCarId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int count  = utility.update(pst);
		
		return count;
		
	}
	
	public int deleteCar(Car car) {
		
		String sql = "delete from car where carId = ?";
		
		pst = utility.createPst(sql);
		
		try {
			pst.setInt(1, car.getCarId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int count  = utility.update(pst);
		
		return count;
		
	}

}
